using System.Net.NetworkInformation;
using static System.Formats.Asn1.AsnWriter;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mili_janerzy
{
    public partial class Form1 : Form
    {
        private int correctAnswer;
        private int score;
        private int questionNumber;
        private int totalQuestions;
        private int percentage;

        public Form1()
        {
            InitializeComponent();
            totalQuestions = 5;
            askQuestion(questionNumber);
        }

        private void checkAnswerEvent(object sender, EventArgs e)
        {
            var senderObject = (Button)sender;
            int buttonTag = Convert.ToInt32(senderObject.Tag);
            if (buttonTag == correctAnswer)
            {
                score++;
            }
            if (questionNumber == totalQuestions)
            {
                percentage = (int)Math.Round(score * 100.0 / totalQuestions);

                MessageBox.Show(
                "Quiz Ended!" + Environment.NewLine +
                "You have answered " + score + " questions correctly." + Environment.NewLine +
                "Your total percentage is " + percentage + "%" + Environment.NewLine +
                "Click OK to play again"
                );
                score = 0;
                questionNumber = 0;
                askQuestion(questionNumber);
            }
            else
            {
                questionNumber++;
                askQuestion(questionNumber);
            }
        }

        private void askQuestion(int qnum)
        {
            switch (qnum)
            {
                case 0:
                    pictureBox1.Image = Properties.Resources.lampart;
                    lblQuestion.Text = "Co to za zwierze?";
                    button1.Text = "puma";
                    button2.Text = "lampart";
                    button3.Text = "jaguar";
                    button4.Text = "tygrys";
                    correctAnswer = 2;
                    break;
                case 1:
                    pictureBox1.Image = Properties.Resources.stonehange;
                    lblQuestion.Text = "Jak nazywa si� obiekt na zdj�ciu?";
                    button1.Text = "Stonehenge";
                    button2.Text = "kamienie";
                    button3.Text = "kamienna twarz";
                    button4.Text = "�ciana p�aczu";
                    correctAnswer = 1;
                    break;
                case 2:
                    pictureBox1.Image = Properties.Resources.rak�w;
                    lblQuestion.Text = "Co to za klub?";
                    button1.Text = "Rak�w Cz�stochowa";
                    button2.Text = "Legia";
                    button3.Text = "Polonia Przemy�l";
                    button4.Text = "�urawianka �urawica";
                    correctAnswer = 4;
                    break;
                case 3:
                    pictureBox1.Image = Properties.Resources.zamekkrolewski;
                    lblQuestion.Text = "Gdzie znajduje si� ten obiekt?";
                    button1.Text = "Zamosc";
                    button2.Text = "Lublin";
                    button3.Text = "Warszawa";
                    button4.Text = "Konin";
                    correctAnswer = 3;
                    break;
            }
        }
    }
}

